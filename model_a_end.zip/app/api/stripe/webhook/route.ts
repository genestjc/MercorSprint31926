import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { getStripe } from "@/lib/stripe";
import { grantPeriodTo } from "@/lib/membership-mint";

/**
 * Fiat → chain bridge.
 * Every successful monthly charge extends the on-chain expiry by 30 days.
 * Cancellation is passive: no more invoices → expiry lapses → paywall locks.
 */
export async function POST(req: NextRequest) {
  const stripe = getStripe();
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  const sig = req.headers.get("stripe-signature");

  if (!stripe || !secret || !sig) {
    return NextResponse.json({ ok: true, mode: "demo" });
  }

  const raw = await req.text();
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(raw, sig, secret);
  } catch (err) {
    return NextResponse.json(
      { error: `Signature verification failed: ${(err as Error).message}` },
      { status: 400 }
    );
  }

  if (event.type === "invoice.paid") {
    const invoice = event.data.object as Stripe.Invoice;
    const subId =
      typeof invoice.subscription === "string"
        ? invoice.subscription
        : invoice.subscription?.id;
    if (subId) {
      const sub = await stripe.subscriptions.retrieve(subId);
      const wallet = sub.metadata?.wallet;
      if (wallet) await grantPeriodTo(wallet);
    }
  }

  // customer.subscription.deleted → no-op. Expiry simply elapses on-chain.

  return NextResponse.json({ received: true });
}

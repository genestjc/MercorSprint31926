import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { getStripe, PRICE_CENTS } from "@/lib/stripe";

/**
 * Creates a Stripe Subscription (recurring $5/mo) and returns the
 * client secret of the first invoice's PaymentIntent so the
 * Payment Element can confirm it.
 *
 * Wallet address is stamped into both customer + subscription metadata.
 * No users table — Stripe holds the wallet pointer, chain holds truth.
 */
export async function POST(req: NextRequest) {
  const { wallet } = await req.json().catch(() => ({ wallet: undefined }));
  const stripe = getStripe();

  if (!stripe) {
    return NextResponse.json({
      clientSecret: "pi_demo_secret_demo",
      mode: "demo",
    });
  }

  // One Stripe customer per wallet — search by metadata, create if absent.
  const existing = await stripe.customers.search({
    query: `metadata['wallet']:'${wallet}'`,
    limit: 1,
  });
  const customer =
    existing.data[0] ??
    (await stripe.customers.create({ metadata: { wallet } }));

  const price = await getOrCreatePrice(stripe);

  const sub = await stripe.subscriptions.create({
    customer: customer.id,
    items: [{ price: price.id }],
    payment_behavior: "default_incomplete",
    payment_settings: {
      save_default_payment_method: "on_subscription",
      payment_method_types: ["card"], // Apple/Google Pay ride on "card"
    },
    expand: ["latest_invoice.payment_intent"],
    metadata: { wallet },
  });

  const invoice = sub.latest_invoice as Stripe.Invoice;
  const pi = invoice.payment_intent as Stripe.PaymentIntent;

  return NextResponse.json({
    clientSecret: pi.client_secret,
    subscriptionId: sub.id,
  });
}

/* Lazy-create a $5/mo price if STRIPE_PRICE_ID isn't set. */
async function getOrCreatePrice(stripe: Stripe): Promise<Stripe.Price> {
  const id = process.env.STRIPE_PRICE_ID;
  if (id) return stripe.prices.retrieve(id);

  const prices = await stripe.prices.search({
    query: "metadata['auto']:'membership-5' AND active:'true'",
    limit: 1,
  });
  if (prices.data[0]) return prices.data[0];

  return stripe.prices.create({
    currency: "usd",
    unit_amount: PRICE_CENTS,
    recurring: { interval: "month" },
    product_data: { name: "Membership" },
    metadata: { auto: "membership-5" },
  });
}

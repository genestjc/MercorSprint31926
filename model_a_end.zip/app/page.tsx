import Link from "next/link";

export default function Home() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-20">
      <h1 className="text-5xl font-title mb-4">Paywalled Blog</h1>
      <p className="text-neutral-600 mb-10">
        Stripe · Sanity · ThirdWeb scaffold.
      </p>
      <Link
        href="/demo"
        className="inline-block bg-black text-white px-5 py-3 font-title tracking-wide"
      >
        View /demo →
      </Link>
    </main>
  );
}
